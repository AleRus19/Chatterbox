#include<stdio.h>
#include<stdlib.h>



int main(int argc,char *argv[]){
  char *endptr;
  char *s; char *f1,*f2;long n;int base=10;
  if(argc==4){
     s=argv[argc-1];
     f1=argv[argc-3];
     f2=argv[argc-2];
  }
  else if(argc==3) {
    s="256";
    f1=argv[argc-2];
    f2=argv[argc-1];
  }
  else {printf("Error");return -1;}
  n=strtol(s,&endptr,base);
  char buf[n];
  FILE *fp1=fopen(f1,"r");
  if(fp1==NULL){perror("file1: ");return -1;}
  FILE *fp2=fopen(f2,"w");
  if(fp2==NULL){perror("file2: ");return -1;}
  while(fread(buf,sizeof(char),1,fp1)){
     fwrite(buf,sizeof(char),1,fp2);
  }
  fclose(fp1);
  fclose(fp2);

  return 0;
}
