#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<dirent.h>
#include<unistd.h>
#include<errno.h>
#include<sys/stat.h>
#include<string.h>

#define N 99999

void processdir(char *buf,char *p){
  if(chdir(buf)==-1){
    perror("chdir"); 
    exit(EXIT_FAILURE);
  }
  char buf1[N];
  getcwd(buf1,N);
  DIR *d;
  struct dirent*  file;
  if((d=opendir(buf1))==NULL){
    perror("opening cwd");
    exit(EXIT_FAILURE);
  }
  while((errno=0,file=readdir(d))!=NULL){
    struct stat info;
    if(stat(file->d_name,&info)==-1){
      perror("Errore: ");
  } 
  else{
   
      if(strcmp(file->d_name,"..")!=0 &&  strcmp(file->d_name,".")!=0)
       if(S_ISDIR(info.st_mode))processdir(file->d_name,buf1);
       else {printf("\n%s\n",buf1);printf("Nome %s:\n",file->d_name);}
    }
  }
  if(errno!=0){
    perror("Readdir: ");  
  }
  if((closedir(d))==-1){exit(EXIT_FAILURE);}
  if(chdir(p)==-1){
    perror("chdir"); 
    exit(EXIT_FAILURE);
  }
 
}


int main(int argc, char *argv[]){
  char buf[N];
  if(getcwd(buf,N)==NULL){
    perror("getcwd");
    exit(EXIT_FAILURE);
  }
  printf("\n%s\n",buf);
  printf("directory %s\n",argv[1]);
  if(chdir(argv[1])==-1){
    perror("chdir"); 
    exit(EXIT_FAILURE);
  }
  char buf1[N];
  getcwd(buf1,N);
  printf("\n%s\n",buf1);
  DIR *d;
  struct dirent*  file;
  if((d=opendir(buf1))==NULL){
    perror("opening cwd");
    exit(EXIT_FAILURE);
  }
  while((errno=0,file=readdir(d))!=NULL){
    struct stat info;
    if(stat(file->d_name,&info)==-1){
      perror("Errore: ");
     } 
 
    else{
      if(strcmp(file->d_name,"..")!=0 &&  strcmp(file->d_name,".")!=0)
        if(S_ISDIR(info.st_mode))processdir(file->d_name,buf1);
    }
  }
  return 0;
}
