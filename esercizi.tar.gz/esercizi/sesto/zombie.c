#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(int argc, char *argv[]){
  int pid;int status;
  for(int i=0;i<atoi(argv[1]);i++){
    pid=fork();  
    if(pid==0){
      execl("/bin/echo","echo","zombie",(char*)NULL);
    }
  }
  sleep(50);
  return 0;
}
