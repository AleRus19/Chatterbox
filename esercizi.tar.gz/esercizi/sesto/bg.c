#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(int argc, char *argv[]){
  int pid;int status;
  pid=fork();
  if(pid==-1){
    perror("Error: ");
    exit(EXIT_FAILURE);
  }  
  if(pid==0){
    int pid1=fork();
    if(pid1==0){
      if( execl("/bin/sleep","sleep",argv[1],(char*)NULL)==-1){
        perror("Error: ");
        exit(EXIT_FAILURE);  
      }
    }
    else{
      waitpid(pid1,&status,0);
      printf("Processo %d, mio padre e' %d \n",(int)getpid(),(int)getppid()); 
      fflush(stdout);
      return 0;   
     }
  }
  return 0;
}
