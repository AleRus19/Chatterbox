#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<pwd.h>
#include<grp.h>
#include<time.h>


void printattr(char *path){
  struct stat info;
  if(stat(path,&info)==-1){
    perror("Errore: ");
  } 
  else{
    printf("Nome %s:\n",path);
    printf("\n i node number %ld\n",(long)info.st_ino);
    printf("tipo: \n");
    if(S_ISREG(info.st_mode)) printf("regular\n");
    else if(S_ISDIR(info.st_mode)) printf("directory\n");
    else if(S_ISLNK(info.st_mode)) printf("link simb\n");
    else if(S_ISCHR(info.st_mode)) printf("character\n");
    else if(S_ISBLK(info.st_mode)) printf("block special\n");
    else if(S_ISFIFO(info.st_mode)) printf("pipe\n");
    // else if (S_ISSOCK(info.st_mode))printf("socket\n");
    else printf("non riconosciuto\n");
    if (S_IRUSR & info.st_mode)putchar('r');
    else putchar('-');
    if (S_IWUSR & info.st_mode) putchar('w');
    else putchar('-');
    if (S_IXUSR & info.st_mode) putchar('x');
    else putchar('-');  
    if (S_IRGRP & info.st_mode)putchar('r');
    else putchar('-');
    if (S_IWGRP & info.st_mode) putchar('w');
    else putchar('-');
    if (S_IXGRP & info.st_mode) putchar('x');
    else putchar('-');    
    if (S_IROTH & info.st_mode)putchar('r');
    else putchar('-');
    if (S_IWOTH & info.st_mode) putchar('w');
    else putchar('-');
    if (S_IXOTH & info.st_mode) putchar('x');
    else putchar('-');printf("\n");  
    struct passwd *pd;
    pd=getpwuid(info.st_uid);
    printf("user name: %s\n", pd->pw_name);
    struct group *grp;
    if ((grp = getgrgid(info.st_gid)) != NULL)
    printf("group name: %s\n", grp->gr_name);
    printf("\n size file  %ld\n",(long)info.st_size);
    printf("ultima modifica: %s\n",ctime(&info.st_mtime));
  }
}


int main(int argc,char *argv[]){
  int i;
  for(i=1;i<argc;i++){
    printattr(argv[i]); 
  }
  return 0;
}
