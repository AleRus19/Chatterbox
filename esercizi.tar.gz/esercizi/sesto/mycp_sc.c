#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>


int main(int argc,char *argv[]){
  int fd1,lung1;char *endptr;
  int fd2,lung2;
  char *s; char *f1,*f2;long n;int base=10;
  if(argc==4){
     s=argv[argc-1];
     f1=argv[argc-3];
     f2=argv[argc-2];
  }
  else if(argc==3) {
    s="256";
    f1=argv[argc-2];
    f2=argv[argc-1];
  }
  else {printf("Error");return -1;}
  n=strtol(s,&endptr,base);
  char buf[n];
  if((fd1=open(f1,O_RDONLY))==-1){
    perror("file1"); exit(EXIT_FAILURE);
  }
  if((fd2=open(f2,O_WRONLY))==-1){
    perror("file2"); exit(EXIT_FAILURE);
  }
  while ((lung1=read(fd1,buf,n))>0){
    if(write(fd2,buf,lung1)==-1){
      perror("file2: write");
      exit(EXIT_FAILURE);
    }  
  }
 
  if(lung1==-1){
    perror("file1");
    exit(EXIT_FAILURE);
  }
 
  if(lung2==-1){
    perror("file2");
    exit(EXIT_FAILURE);
  }

  if(close(fd1)==-1){
    perror("file1: close");
    exit(EXIT_FAILURE);
  }
  
  if(close(fd2)==-1){
    perror("file1: close");
    exit(EXIT_FAILURE);
  }

  return 0;
}
