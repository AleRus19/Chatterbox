#!bin/bash

file=$1
key=$2

if [ ! $# -eq 2 ]; then
    echo usa: $(basename $0) file key
    exit 1
fi

if [ ! -f "$file" ]; then
   echo "File $file does not exist."
   exit 1 
fi


IFS='='
while read -a words -r line 
do 
  if [ "$key"  == "${words[0]}" ]; then 
    echo "${words[1]}" 
    exit 0
  fi
  
  
done<"$file"

echo "Key non presente"
