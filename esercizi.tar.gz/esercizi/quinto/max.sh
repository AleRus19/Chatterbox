#!bin/bash

if [ ! $# -eq 1 ]; then
    echo usa: $(basename $0)  file
    exit 1
fi


file=$1


 if [ ! -f "$file" ]; then
   echo "File $file  does not exist."
   exit 1 
fi


IFS=' '
max=0
sum=0
i=0
while read -a words -r line 
do 
  if [ $max -lt "${words[16]}" ]; then 
       max=${words[16]}
       ((sum=sum+${words[16]}))
  fi
  ((i++))
done<"$file"

((avg=sum/i))
echo "max:$max avg:$avg"

