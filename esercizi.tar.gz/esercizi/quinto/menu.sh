#!/bin/bash
# This script will test if you have given a leap year or not.


file1=$1
file2=$2

if [ ! -f $file1 ]; then
   echo "File $file1  does not exist."
   exit 1 
fi

if [ ! -f $file2 ]; then
   echo "File $file2  does not exist."
   exit 1 
fi


echo "Scegli e premi [ENTER]:"

echo "1.rimuovere i file f1 ed f2"
echo "2.archiviare i file f1 e f2"
echo "3.appendere il file f1 al file f2"
echo "4.esci"

read opt
 
if [ $opt -lt 0 ]; then
  echo "Scelta errata."
fi

if [ $opt -gt 4 ]; then
  echo "Scelta errata."
fi


if [ $opt -eq 1 ]; then
  rm -i  $file1
  rm -i $file2
fi


if [ $opt -eq 2 ]; then
  tar cf log.tar $file1 $file2  | gzip log*
fi

if [ $opt -eq 3 ]; then
  exec 0>>$file2
  cat $file1>&0
fi



if [ $opt -eq 4 ]; then
  exit 0
fi









