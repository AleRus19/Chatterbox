#!/bin/bash

if [ $# -lt 2 ]; then
    echo usa: $(basename $0) minimo 3 file
    exit 1
fi

path=$@ 
IFS=' ' read -r -a array <<< "$path"
ultimo="${array[($#-1)]}"
 
for((i=0;i<$#;i++)){    
  if [ ! -f "${array[($i)]}" ]; then
   echo "File ${array[($i)]} does not exist."
   exit 1 
fi
}

exec 0>>"$ultimo"
 
for((i=($#-2);i>=0;i--)){
  cat "${array[($i)]}">&0
}

