#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<unistd.h>
#include<errno.h>
#include<sys/wait.h>


#define UNIX_PATH_MAX 108

#define SOCKNAME "./mysock"

int main(int argc,char *argv[]){
  char buf[255];char res[255];
  int fd_server;int fd_c;int status3; 
  int status1;  struct sockaddr_un sa;
  strncpy(sa.sun_path,SOCKNAME,UNIX_PATH_MAX);
  sa.sun_family=AF_UNIX;
  fd_server=socket(AF_UNIX,SOCK_STREAM,0);
  bind(fd_server,(struct sockaddr *)&sa,sizeof(sa));
  listen(fd_server,SOMAXCONN);
  fd_c=accept(fd_server,NULL,0);
  while(1){
    int pipe1[2];
    if(pipe(pipe1)==-1){perror("Error: ");return 0;}
    int pipe2[2];
    if(pipe(pipe2)==-1){perror("Error: ");return 0;}
    read(fd_c,buf,100);fflush(stdout);fflush(stdin);fflush(stdout);
    printf("Server:ricevuto: %s\n",buf);
    buf[strlen(buf)]='\n';   
    write(pipe1[1],buf,strlen(buf));  
    close(pipe1[1]);
    int pid1; 
    dup2(pipe1[0],0);
    close(pipe1[0]);
    pid1=fork();
    if(pid1==0){
      close(pipe2[0]);
      dup2(pipe2[1],1);   
      close(pipe2[1]);
      execl("/usr/bin/bc","bc",(char*)NULL);
    }
    else{
       waitpid(pid1,&status1,0);
       close(pipe2[1]);
       read(pipe2[0],res,100);
       close(pipe2[0]);
       write(fd_c,res,100);
   }
  }
  close(fd_server);
  close(fd_c);
  return 0;
}
