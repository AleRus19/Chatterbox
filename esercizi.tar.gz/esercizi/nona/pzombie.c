#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc,char *argv[]){
  int pipe1[2];int status1,status2,status3;
  int pid1,pid2,pid3;
  if(pipe(pipe1)==-1){perror("Error: ");return 0;}
  pid1=fork();
  if(pid1==0){
    close(pipe1[0]);
    dup2(pipe1[1],1);
    close(pipe1[1]);
    execl("/bin/ps","ps","-A","-ostat,pid",(char*)NULL);    
  } 
  else{
    close(pipe1[1]);
  dup2(pipe1[0],0);
  close(pipe1[0]);
  int pipe2[2];
  // if(pipe(pipe2)==-1){perror("Error: ");return 0;}
  pid2=fork();
  if(pid2==0){
      close(pipe2[0]);
    dup2(pipe2[1],1);
    close(pipe2[1]);
     execl("/bin/grep","grep","-e","[zZ]",(char*)NULL); 
  }
  else{  
  pid3=fork();
  if(pid3==0){
     dup2(pipe2[0],0);
     close(pipe2[0]);
     close(pipe2[1]);
     execl("/bin/awk","awk","'{","print","$2","}'",(char*)NULL); 
   }
  else waitpid(pid3,&status3,0);
  } 
          waitpid(pid2,&status2,0);

     waitpid(pid1,&status1,0); 

   //    printf("Figli terminati\n");
  }
  
     return 0;
}
