#include<stdio.h>
#include<stdlib.h>

#define N 1028

#define CHECK_PTR(ptr,s)if(ptr==NULL){perror(#s);return -1;}

int somma(int x){
  static int  tot=INIT_VALUE;
  tot+=x;
  return tot;
}

int main(int argc, char *argv[]){
  int base=10; char *endptr=NULL; char *s=(char *)malloc(N*sizeof(char));
  char *input=argv[1];
  FILE *fp=fopen(input,"r");
  CHECK_PTR(fp,opening input);
  while((fgets(s,N+2,fp))!=NULL){
    int x=strtol(s,&endptr,base);
    printf("%d \n ",somma(x));  
  }
  fclose(fp);
  free(s);
  return 0;
}
