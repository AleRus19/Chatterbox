#include<stdio.h>
#include<stdlib.h>

#define CHECK_PTR(ptr,s)if(ptr==NULL){perror(#s);return -1;}

int main(int argc, char *argv[]){
  FILE * fp;
  fp=fopen("fileprova.txt","r");
  CHECK_PTR(fp,opening fileprova.txt);
  fclose(fp);
  return 0;
}
