#include<stdio.h>
#include<stdlib.h>


#define dimN 16
#define dimM  8
#define size_t long

#define CHECK_PTR(ptr,s)if(ptr==NULL){perror(s);}

#define ELEM(ptr,i,j) ptr[(i*dimM)+j]

#define PRINTMAT(ptr) \
        for(size_t i=0;i<dimN;++i){ \
         for(size_t j=0;j<dimM;++j){\
           printf("%ld ",ELEM(M,i,j) );} \
         printf("\n");}
 

int main() {
    long *M = malloc(dimN*dimM*sizeof(long));
    CHECK_PTR(M, "malloc"); 
    for(size_t i=0;i<dimN;++i)
	for(size_t j=0;j<dimM;++j)			
	    ELEM(M,i,j) = i+j;    
    
    PRINTMAT(M);
    free(M);
    return 0;
}
