#include<stdio.h>
#include<stdlib.h>
#include<string.h>



#define ALLOCA(s) (float *)malloc(s*s*sizeof(float))

#define CHECK_MAT(ptr,s) if(ptr==NULL){perror(s); return -1;}

#define ELEM(ptr,i,j,s) ptr[(i*s)+j]



void Confronta(float *m1,float *m2,int size,int (*f) (const void *,const void *,size_t)){
  int n=0;
  n=memcmp(m1,m2,n); 
  if (n>0) printf ("m1' is greater than m2\n");
  else if (n<0) printf ("m1  is less than m2\n");
  else printf ("m1 is the same as m2\n"); 
  return ;
}


int main(int argc, char *argv[]){
  int n;
  scanf("%d",&n);
  if(n>512){printf("Numero troppo grande : <512");return 0;}
  float *m1; 
  m1=ALLOCA(n);
  CHECK_MAT(m1,"malloc");
  
  for(size_t i=0;i<n;++i)
	for(size_t j=0;j<n;++j)			
	  ELEM(m1,i,j,n)= (i+j)/6668.0;     
  FILE *fpt=fopen("testo.txt","w");
  for(size_t i=0;i<n;++i){
    for(size_t j=0;j<n;++j){			
	  float e=ELEM(m1,i,j,n); 
          fprintf(fpt,"%f\n",e);
    }
  }
  FILE *fpb=fopen("binario.dat","wb");
  for(size_t i=0;i<n;++i){
    for(size_t j=0;j<n;++j){			
	  float e=ELEM(m1,i,j,n); 
          fwrite(&e,sizeof(float),1,fpb);
    }
  }
  fclose(fpb);
  float *m2=ALLOCA(n);
  CHECK_MAT(m2,"malloc");
  fpb=fopen("binario.dat","rb");
  for(size_t i=0;i<n;++i){
    for(size_t j=0;j<n;++j){			
          float e; 
          fread(&e,sizeof(float),1,fpb);
          ELEM(m1,i,j,n)=e;
    }
  } 
  Confronta(m1,m2,n,memcmp);
  free(m1);
  free(m2);
  fclose(fpt);
  fclose(fpb);
  return 0;
}
