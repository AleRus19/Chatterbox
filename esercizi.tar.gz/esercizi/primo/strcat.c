#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 
#define RIALLOCA(buf, newsize) \
 buf=realloc(buf,newsize*sizeof(char *)) 

 char* mystrcat(char *buf, int sz, char *first, ...) {
  va_list op;
  va_start(op,first);
  int cont=0;
  while(va_arg(op,char *)!=NULL)cont++;
  va_end(op);
  va_start(op,first);  
  strncat(buf,first,sz);
  for(int i=0;i<cont;i++){
    char *ptr=va_arg(op,char *);
    sz+=strlen(ptr); RIALLOCA(buf,sz);
    strncat(buf,ptr,strlen(ptr));
  } 
  va_end(op);
  return buf;
  }  
 
int main() {
  char *buffer=NULL;
  RIALLOCA(buffer,16);  // macro che effettua l'allocazione
  buffer[0]='\0';
  buffer = mystrcat(buffer, 16, "prima stringa", "seconda", "terza molto molto molto lunga", "quarta", "quinta lunga", "ultima!",NULL);
     printf("%s\n", buffer);
     ;
      
  free(buffer);
  return 0;
}
