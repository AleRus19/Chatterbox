#include<stdio.h>
#include<stdlib.h>

struct node_t{
  long key;
  struct node_t *left;
  struct node_t *right;
};

void deleteTree(struct node_t *root){
  if(root==NULL) return;
  deleteTree(root->left);
  deleteTree(root->right);
  free(root);
  return ; 
}


void printInOrder(struct node_t *root){
  if(root==NULL)return ;
  printInOrder(root->left);
  printf("%ld, ",root->key);
  printInOrder(root->right);
}

struct node_t *buildTree(long elem, struct node_t *t){
  if(t==NULL){
    struct node_t* new=(struct node_t *)malloc(sizeof(struct node_t));
    new->key=elem;
    new->left=NULL;
    new->right=NULL;
    return new;
  }
  if(t->key<elem)t->right=buildTree(elem,t->right);
  else t->left=buildTree(elem,t->left);
  return t;
}

long getMax(struct node_t *root){
  if(root->left==NULL && root->right==NULL) return root->key;
  getMax(root->right);
}


long getMin(struct node_t *root){
  if(root->left==NULL && root->right==NULL) return root->key;
  getMin(root->left);
}


int main(int argc, char *argv[]) {
    struct node_t *root = NULL;
    const long array_size = 10;
    long array[] = { 12, 32, 18, -1, 0, 18, -5, 54, 28, 15};
    
    for(long i=0; i<array_size; ++i)
	root = buildTree(array[i], root);
    
    printf("Min: %ld\n", getMin(root));
    printf("Max: %ld\n", getMax(root));
    
    printInOrder(root);
    printf("\n");
    
    deleteTree(root);
    root=NULL;
  
    return 0;
}
