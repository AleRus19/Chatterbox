#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char **argv, char **envp){
  long val;char *endptr;int base=10; char *s;
  printf("%s\n",argv[0]);
  for(int i=1;i<argc;i++){
    char *s=argv[i];
    if(strcmp(s,"-n")==0 || strcmp(s,"-m")==0 ){
      if(i<argc-1)i++; else {printf("error \n"); return 0;};
      char *s1=argv[i];
      val=strtol(s1,&endptr,base);
      if(endptr==s1){printf("error\n");return 0;}//nessun numero
      else  if(*endptr!='\0'){printf("error\n");return 0;}//caratteri dopo numero
      else printf("%s: %ld\n",s,val);
    }
    else if(strcmp(s,"-h")==0){
      printf("messaggio d usage\n");
      return -1; 
    }
    else if(strcmp(s,"-s")==0){
      i++;
      printf("%s: %s\n",s,argv[i]); 
    }
    else{
      printf("Operazione %s non riconosciuta\n",s);
      return -1; 
    }
   
    /*  else if(strlen(s)>2){
      char *buffer=NULL;
      strncat(buffer,s,2);
      int j=2;char *s2=NULL;int p=0;
      while(s[j]!='\0'){s2[p]=s[j];j++;p++;}s2[p]='\0';
      if(strcmp(buffer,"-n")==0 || strcmp(buffer,"-m")==0 ){
      val=strtol(s2,endptr,base);
      if(*endptr==s2)printf("error\n");
      else printf("%s: %ld\n",buffer,val);  
      }
      }*/
  }
}
