#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<errno.h>
#include<sys/wait.h>
#include<pthread.h>
#include<unistd.h>
#include<time.h>
#include<sys/select.h>


#define UNIX_PATH_MAX 108

#define SOCKNAME "./mysock"

#define N 100


static inline int readn(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=read((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;   // gestione chiusura socket
        left    -= r;
	bufptr  += r;
    }
    return size;
}

static inline int writen(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=write((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;  
        left    -= r;
	bufptr  += r;
    }
    return 1;
}

int aggiorna(fd_set *set,int max){
  int fd;int fd_num=0;
  for(fd=0;fd<=max;fd++){
    if(FD_ISSET(fd,set)){
      if(fd>fd_num)fd_num=fd;  
    }
  } 
  return fd_num;
}




int main(int argc,char *argv[]){
  char buf[N];
  int fd_server; int fd_num=0;
  int fd;
  fd_set set,rdset;
  int nread; 
  int l; int fd_c;
  struct sockaddr_un sa;
  strncpy(sa.sun_path,SOCKNAME,UNIX_PATH_MAX);
  sa.sun_family=AF_UNIX;
  fd_server=socket(AF_UNIX,SOCK_STREAM,0);
  bind(fd_server,(struct sockaddr *)&sa,sizeof(sa));
  listen(fd_server,SOMAXCONN);
  if(fd_server>fd_num)fd_num=fd_server;
  FD_ZERO(&set);
  FD_SET(fd_server,&set);
  while(1){
    rdset=set;
    if(select(fd_num+1,&rdset,NULL,NULL,NULL)==-1){
      perror("Error: "); break; 
    }  
    else{
      for(fd=0;fd<=fd_num;fd++){
        if(FD_ISSET(fd,&rdset)){
          if(fd==fd_server){
            fd_c=accept(fd_server,NULL,0);
            printf("Nuova Connessione: %d\n",fd_c);
            FD_SET(fd_c,&set);
            if(fd_c>fd_num)fd_num=fd_c;  
          } 
          else{
            nread=readn(fd,&l,sizeof(int));
            nread=readn(fd,buf,l);
            if(nread==0){
              FD_CLR(fd,&set);
              fd_num=aggiorna(&set,fd_num);
              printf("Disconnesso: %d\n",fd);
              close(fd);
            }
	    else{printf("Ricevuta stringa:%s l:%d\n",buf,l);
                writen(fd,&l,sizeof(int));writen(fd,buf,l);}
          }
       }
      }    
    }
  }
    close(fd_server);
    return 0;
}
