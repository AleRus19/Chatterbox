#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<errno.h>
#include<sys/wait.h>
#include<pthread.h>
#include<unistd.h>
#include<time.h>


#define UNIX_PATH_MAX 108

#define SOCKNAME "./mysock"




static inline int readn(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=read((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;   // gestione chiusura socket
        left    -= r;
	bufptr  += r;
    }
    return size;
}

static inline int writen(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=write((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;  
        left    -= r;
	bufptr  += r;
    }
    return 1;
}





static void *worker(void* a){
  int  fd=*((int*)a); 
  char buf[255];int n,l;
  while(1){
    n=readn(fd,&l,sizeof(int));
    n=readn(fd,buf,l);
    if(n==0)break;
    printf("Thread:ricevuto dal client %d: %s\n",fd,buf);
    writen(fd,&l,sizeof(int));
    writen(fd,buf,l);
  }
  printf("Disconnesso:%d\n",fd);
  close(fd);free(a);
  return (void*) NULL;
}

int main(int argc,char *argv[]){
  char buf[255];
  int fd_server; 
  int status1;  struct sockaddr_un sa;
  strncpy(sa.sun_path,SOCKNAME,UNIX_PATH_MAX);
  sa.sun_family=AF_UNIX;
  fd_server=socket(AF_UNIX,SOCK_STREAM,0);
  bind(fd_server,(struct sockaddr *)&sa,sizeof(sa));
  listen(fd_server,SOMAXCONN);
  int err;
  int i=0; 
  while(1){
    i=accept(fd_server,NULL,0);
    int *fd_c=(int *)malloc(sizeof(int));
    *fd_c=i;
    pthread_t tid;
    printf("Nuova connessione: %d\n",*fd_c);
    if(err=pthread_create(&tid,NULL,worker,fd_c)!=0){
      perror("Error: ");
      exit(EXIT_FAILURE);
    } 
    if(err=pthread_detach(tid)!=0){
      perror("Error: ");
      exit(EXIT_FAILURE);
    }
  }
  /*  int *status=(int *)malloc(10*sizeof(pthread_t));  
   for(int j=0;j<i;j++){
    pthread_join(ptr[j],(void*)&status[j]);
  } 
   for(int j=0;j<i;j++){
   printf("StatusT:%d\n",status[j]);
  }  
  free(status);*/
  close(fd_server);
  return 0;
}
