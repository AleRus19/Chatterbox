#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<errno.h>
#include<sys/wait.h>
#include<pthread.h>
#include<unistd.h>
#include<time.h>
#include<sys/select.h>

struct node{
  long info;
  struct node *next;
};

struct node *head=NULL;
struct node *last=NULL;
int nelem=0;

pthread_mutex_t mtx=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t empty=PTHREAD_COND_INITIALIZER;

#define N 100
#define UNIX_PATH_MAX 108

#define SOCKNAME "./mysock"



void push(struct node* n){
    pthread_mutex_lock(&mtx);
    if(head==NULL){head=n;last=head;}
    else{ 
      last->next=n;
      last=last->next;
    }
    nelem++;
    printf("Inserito:%ld\n",n->info);
    if(n->info==-1)pthread_cond_broadcast(&empty);
    else pthread_cond_signal(&empty);
    pthread_mutex_unlock(&mtx);
}


int pop(){
  pthread_mutex_lock(&mtx);
  while(nelem==0){
    pthread_cond_wait(&empty,&mtx);
    //printf("Consumatore risvegliato\n");
  }
  struct node * n=head; 
  if(n->info==-1){
    //printf("Il produttore ha terminato\n");
    pthread_mutex_unlock(&mtx);
    return -1;
  }
  head=head->next;
  nelem--;printf("Consuma:%ld\n",n->info);int r=n->info;
  pthread_mutex_unlock(&mtx);free(n);
  return r;
}




static inline int readn(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=read((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;   // gestione chiusura socket
        left    -= r;
	bufptr  += r;
    }
    return size;
}

static inline int writen(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=write((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;  
        left    -= r;
	bufptr  += r;
    }
    return 1;
}


static void *listener(void* a){
  char buf[N]; int fd_server; int fd_num=0;
  int fd;fd_set set,rdset;int nread; 
  int l; int fd_c;int conn=0;
  struct sockaddr_un sa;
  strncpy(sa.sun_path,SOCKNAME,UNIX_PATH_MAX);
  sa.sun_family=AF_UNIX;
  fd_server=socket(AF_UNIX,SOCK_STREAM,0);
  bind(fd_server,(struct sockaddr *)&sa,sizeof(sa));
  listen(fd_server,SOMAXCONN);
  if(fd_server>fd_num)fd_num=fd_server;
  FD_ZERO(&set);
  FD_SET(fd_server,&set);
  while(1){
    if(conn==4){break;}
    rdset=set;
    if(select(fd_num+1,&rdset,NULL,NULL,NULL)==-1){
      perror("Error: "); break; 
    }  
    else{
      if(FD_ISSET(fd_server,&set)){
        fd_c=accept(fd_server,NULL,0);
        printf("Nuova Connessione: %d\n",fd_c);conn++;
        	struct node *n=(struct node *) malloc(sizeof(struct node));
        n->info=fd_c;n->next=NULL;
        push(n);  if(fd_c>fd_num)fd_num=fd_c; 
     } 
    }
    }
     	struct node *n=(struct node *) malloc(sizeof(struct node));   
        n->info=-1;n->next=NULL;
	push(n);
	close(fd_server);
  return (void*) 2;
}


static void *worker(){
  while(1){
    int  fd=pop(); 
    if(fd==-1){break;}
    char buf[N];int n=0,l=0;
  while(1){
    n=readn(fd,&l,sizeof(int));
    if(n==0)break;
    n=readn(fd,buf,l);
    if(n==0)break;
    printf("Thread:ricevuto dal client %d: %s\n",fd,buf);
    writen(fd,&l,sizeof(int));
    writen(fd,buf,l);
  }
  printf("Disconnesso:%d\n",fd);
  close(fd);
  }
  return (void*) 1;
}

int main(int argc,char *argv[]){
  int nt=atoi(argv[1]);
  pthread_t *ptr=(pthread_t *)malloc((nt+1)*sizeof(pthread_t));
  int* status1=(int *)malloc((nt+1)*sizeof(int));
  int err;  
  for(int i=0;i<nt;i++){
    if(err=pthread_create(&ptr[i],NULL,worker,NULL)!=0){
      perror("Error: ");
      exit(EXIT_FAILURE);
    }
  }
  pthread_t pl;int sl;
  if(err=pthread_create(&pl,NULL,listener,NULL)!=0){
      perror("Error: ");
      exit(EXIT_FAILURE);
  }
   pthread_join(pl,(void*)&sl);
  for(int i=0;i<nt;i++){
    pthread_join(ptr[i],(void*)&status1[i]);
  } 
  
  
   for(int i=0;i<nt;i++){
   printf("StatusT:%d\n",status1[i]);
  }  
   printf("StatusL:%d\n",sl);
  free(status1);
  free(ptr);free(head);
  return 0;
}
