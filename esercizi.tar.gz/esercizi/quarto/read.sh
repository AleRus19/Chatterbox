#!bin/bash

input=$1

 read -d '\n' -r -a array <$1
 t2=${#array[@]} 

echo $t2

