#!/bin/bash

dir=$1
par=$2
num=$3


pa=$(locate --basename  $dir)


#se il numero degli argomenti $# è less then 2 esce
if [ $# -lt 2 ]; then 
  echo usa: $(basename $0) dir par num
  exit 1
fi

#controlla se è una directory oppure no
if [ ! -d $pa ]; then
   echo $1 is not a directory
   exit 1
fi

if [ $3 -le 0 ]; then 
  echo "$3 non è un numero valido"
  exit 1
fi



for((i=0;i<num;i++)){
  find $pa -mmin $i  -exec grep $2  '{}' \; -print
}

