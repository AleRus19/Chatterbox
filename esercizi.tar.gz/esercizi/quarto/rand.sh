#!bin/bash

n=$1
m=$2

for((i=0; i<$1; i+=1)); do
  numero=$RANDOM
  let "numero %= $2"
  echo "$numero"
  
done
