#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<unistd.h>
#include<errno.h>

#define UNIX_PATH_MAX 108

#define SOCKNAME "./mysock"



static inline int readn(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=read((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;   // gestione chiusura socket
        left    -= r;
	bufptr  += r;
    }
    return size;
}

static inline int writen(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=write((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;  
        left    -= r;
	bufptr  += r;
    }
    return 1;
}



int main(int argc,char *argv[]){
  int fd_client; 
  struct sockaddr_un sa;
  strncpy(sa.sun_path,SOCKNAME,UNIX_PATH_MAX);
  sa.sun_family=AF_UNIX;
  int bl=0;
  fd_client=socket(AF_UNIX,SOCK_STREAM,0);
  while(connect(fd_client,(struct sockaddr*)&sa,sizeof(sa))==-1){
    if(errno==ENOENT){printf("In attesa di connesione..\n");sleep(1);}
    else exit(EXIT_FAILURE);  
  }
  int n;int l; char *buf=(char *)malloc(100*sizeof(char));  
  while(1){
    char  *line=(char *)malloc(100*sizeof(char));
    fgets(line,100,stdin);
    line[strlen(line)-1]='\0';
    if(strcmp("q",line)==0){break;}
    else{
      l=strlen(line)+1;
      writen(fd_client,&l,sizeof(int));
      writen(fd_client,line,l);
      readn(fd_client,&n,sizeof(int));
      readn(fd_client,buf,l);
      printf("Risultato:%s\n",buf);
       free(line);
    }   
  }
  close(fd_client);
  return 0;
}


