#define _POSIX_C_SOURCE 200112L
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<errno.h>
#include<sys/wait.h>
#include<pthread.h>
#include<unistd.h>
#include<signal.h>
#include<ctype.h>

#define UNIX_PATH_MAX 108

#define SOCKNAME "./mysock"

volatile sig_atomic_t t=0;
void gestore_int(int sig){
  //  write(1,"socket cancellato\n",strlen("socket cancellato")+1);
  unlink(SOCKNAME);
  _exit(0);
}

static inline int readn(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=read((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;   // gestione chiusura socket
        left    -= r;
	bufptr  += r;
    }
    return size;
}

static inline int writen(long fd, void *buf, size_t size) {
    size_t left = size;
    int r;
    char *bufptr = (char*)buf;
    while(left>0) {
	if ((r=write((int)fd ,bufptr,left)) == -1) {
	    if (errno == EINTR) continue;
	    return -1;
	}
	if (r == 0) return 0;  
        left    -= r;
	bufptr  += r;
    }
    return 1;
}

static void *worker(void* a){
  long  fd=(long)a; 
  char buf[255];int n,l;
  while(1){
    n=readn(fd,&l,sizeof(int));
    n=readn(fd,buf,l);
    if(n==0)break;
    printf("Thread:ricevuto dal client %ld: %s\n",fd,buf);
    writen(fd,&l,sizeof(int));
    writen(fd,buf,l);
  }
  printf("Disconnesso:%ld\n",fd);
  close(fd);
  return (void*) NULL;
}
  
static void *threadl(void* set){
  sigset_t s=(sigset_t) s;int sig;
   sigemptyset(&s);
  sigaddset(&s,SIGINT);
  pthread_sigmask(SIG_SETMASK,&s,NULL);
 
  sigwait(&s,&sig);
  printf("\nSegnale ricevuto\n");
  unlink(SOCKNAME);
  exit(0);
}


void spawnl(sigset_t set){
  pthread_attr_t thattr;
  pthread_t thid;
  if(pthread_attr_init(&thattr)!=0){
    //fprintf(stderr,"pthread_attr_init FALLITA\n");
    return ;
  }
  //settiamo il thread in modalità detached
  if(pthread_attr_setdetachstate(&thattr,PTHREAD_CREATE_DETACHED)!=0){
    //fprintf(stderr,"pthread_attr_setdetached FALLITA\n");
    pthread_attr_destroy(&thattr);
    return ;
  }
  if(pthread_create(&thid,&thattr,threadl,&set)!=0){
    // fprintf(stderr,"pthread_create FALLITA");
    pthread_attr_destroy(&thattr);
    return ;
  } 
}


void spawn(long connfd){
  pthread_attr_t thattr;
  pthread_t thid;
  if(pthread_attr_init(&thattr)!=0){
    //fprintf(stderr,"pthread_attr_init FALLITA\n");
    close(connfd);
    return ;
  }
  //settiamo il thread in modalità detached
  if(pthread_attr_setdetachstate(&thattr,PTHREAD_CREATE_DETACHED)!=0){
    //fprintf(stderr,"pthread_attr_setdetached FALLITA\n");
    pthread_attr_destroy(&thattr);
    close(connfd);
    return ;
  }
  if(pthread_create(&thid,&thattr,worker,(void*)connfd)!=0){
    // fprintf(stderr,"pthread_create FALLITA");
    pthread_attr_destroy(&thattr);
    close(connfd);
    return ;
  } 
}

int main(int argc,char *argv[]){
  sigset_t set; int sig;
  sigemptyset(&set);
  sigaddset(&set,SIGINT);
  pthread_sigmask(SIG_SETMASK,&set,NULL);
  spawnl(set);
  int fd_server; 
  int status1;  struct sockaddr_un sa;
  strncpy(sa.sun_path,SOCKNAME,UNIX_PATH_MAX);
  sa.sun_family=AF_UNIX;
  fd_server=socket(AF_UNIX,SOCK_STREAM,0);
  bind(fd_server,(struct sockaddr *)&sa,sizeof(sa));
  listen(fd_server,SOMAXCONN);
  while(1){ 
    long i; 
    i=accept(fd_server,NULL,0);
    spawn(i);
  }  
  return 0;
}
