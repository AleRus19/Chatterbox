#include<stdio.h>
#include<stdlib.h>
#include<getopt.h>
#include<pthread.h>
#include<string.h>
#include<unistd.h>

struct node{
  char info[255];
  struct node *next;
};


struct node2{
  char nome[255];
  int l;
  int w;
  struct node2 *next;
};

int letti=0;

int nelem=0;
struct node *inQ=NULL;
struct node *lastinQ=NULL;
struct node2 *outQ=NULL;
struct node2 *lastoutQ=NULL;

int nelem2=0;

pthread_mutex_t mtx1=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t empty1=PTHREAD_COND_INITIALIZER;

pthread_mutex_t mtx2=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t empty2=PTHREAD_COND_INITIALIZER;


struct argT{
  int l;
  int w;
};

struct node2* popOut(){
  pthread_mutex_lock(&mtx2);
  while(nelem2==0){
    pthread_cond_wait(&empty2,&mtx2);
    //printf("Consumatore risvegliato\n");
  }
  struct node2 * n=outQ; 
  outQ=outQ->next;
  nelem2--;letti++;sleep(2);
  pthread_mutex_unlock(&mtx2);
  return n;
  }



void PushOut(char * key,int l,int w){
    pthread_mutex_lock(&mtx2);
    struct node2* n=malloc(sizeof(struct node2));
    strcpy(n->nome,key);
    n->l=l;
    n->w=w;
    n->next=NULL;
    if(outQ==NULL){outQ=n;lastoutQ=outQ;}
    else{ 
      lastoutQ->next=n;
      lastoutQ=lastoutQ->next;
    }
    nelem2++;
    //    printf("Inserito2:%s\n",n->nome);sleep(2);
    pthread_cond_signal(&empty2);
    pthread_mutex_unlock(&mtx2);
}




int Tokenizza(char *s){
  int w=0;
  char *token=strtok(s," ");
  while(token){    
    token=strtok(NULL," ");
    w++;
  }
  return w;
}


void Esamina(char *key){
  int line=0,word=0; 
  FILE *fp=fopen(key,"r");
  char s[255];
  if(fp==NULL){perror("Error: "); return;}
  while((fgets(s,255,fp))!=NULL){
    line++;
    word+=Tokenizza(s);
  }
  fclose(fp);
  PushOut(key,line,word);
}

int pop(){
  pthread_mutex_lock(&mtx1);
  while(nelem==0){
    pthread_cond_wait(&empty1,&mtx1);
    //printf("Consumatore risvegliato\n");
  }
  struct node * n=inQ; 
  if(strcmp(n->info,"EOF")==0){
    //printf("Il produttore ha terminato\n");
    pthread_mutex_unlock(&mtx1);
    return -1;
  }
  inQ=inQ->next;
  nelem--;//printf("Consuma:%s\n",n->info);sleep(2);
  pthread_mutex_unlock(&mtx1);
  Esamina(n->info);free(n);
  return 0;
}


void push(char * key){
    pthread_mutex_lock(&mtx1);
    struct node* n=malloc(sizeof(struct node));
    strcpy(n->info,key);
    n->next=NULL;
    if(inQ==NULL){inQ=n;lastinQ=inQ;}
    else{ 
      lastinQ->next=n;
      lastinQ=lastinQ->next;
    }
    nelem++;
    //printf("Inserito:%s\n",n->info);sleep(2);
    if(strcmp(n->info,"EOF")==0)pthread_cond_broadcast(&empty1);
    else pthread_cond_signal(&empty1);
    pthread_mutex_unlock(&mtx1);
}


static void *worker(void* e){
  struct argT* m=(struct argT*)e;
  while(1){
    int c=pop();
    if(c==-1){/*printf("Il produttore ha terminato\n");*/return (void*) 2;}
  }
  return (void*) 2;
}



int main(int argc, char *argv[]){
  int opt;int wflag=0; int ntflag=0; int lflag=0; char s[233];
  while((opt=getopt(argc,argv,"wlt:"))!=-1){
    switch(opt){
      case 'w':
        wflag=1;
        break;
      case 'l':
        lflag=1;
        break;
     case 't':
        ntflag=atoi(optarg);
      break;
    default : strcpy(s,optarg);
  }
  }
  printf("num:%d\n",ntflag);
  printf("w:%d\n",wflag);
  printf("l:%d\n",lflag);
  printf("optind:%d\n",optind);

  char files[255][255];int nf=0;
  while(optind<argc){
    strcpy(files[nf],argv[optind]);
    nf++;optind++;
  }
  pthread_t *ptr=(pthread_t *)malloc(ntflag*sizeof(pthread_t));
  int *status=(int *)malloc(ntflag*sizeof(pthread_t)); 
 
  int err; struct argT *e=malloc(sizeof(struct argT));
  e->l=wflag;
  e->w=lflag;
  for(int i=0;i<ntflag;i++){
    if(err=pthread_create(&ptr[i],NULL,worker,(void*)e)!=0){
      perror("Error: ");
      exit(EXIT_FAILURE);
    }
  }
  
  for(int i=0;i<nf;i++){
    push(files[i]);
  }
  push("EOF");
  int c=0;
  while(c==0){
    struct node2 *n=popOut();
    
    if(wflag==1 && lflag==1)printf("\n\t%s\n\tline:%d\n\tword:%d\n\n",n->nome,n->l,n->w);
   if(wflag==1 && lflag==0)printf("\n\t%s\n\tword:%d\n\n",n->nome,n->w);
   if(wflag==0 && lflag==1)printf("\n\t%s\n\tline:%d\n",n->nome,n->l);
    if(wflag==0 && lflag==0)printf("\n\t%s\n",n->nome);
      
   
    if(letti==nf){ c=1;}
  }
  
 for(int i=0;i<ntflag;i++){
    pthread_join(ptr[i],(void*)&status[i]);
  } 
 for(int i=0;i<ntflag;i++){
    printf("StatusT:%d\n",status[i]);
  }  
 
  return 0;
}
