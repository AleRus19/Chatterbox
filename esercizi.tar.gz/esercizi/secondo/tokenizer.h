int somma(int a, int b);
int differenza(int a,int b);
