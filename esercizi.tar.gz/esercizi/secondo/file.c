#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define N 1024

int main(int argc, char *argv[]){
   if(argc<3){
     fprintf(stderr, "use: %s input.txt output.txt \n",argv[0]);
     return -1;
   }
   char *input,*output;
   char *str1=(char *)malloc((N+2)*sizeof(char));
   char *token1=(char *)malloc((N+2)*sizeof(char));
   input=argv[1];
   output=argv[2];
   FILE * ifp, *ofp;
   ifp= fopen (input,"r");
   if(ifp==NULL){perror("Error: ");return -1;}
   if(argc==4 && strcmp(argv[3],"a")==0) ofp= fopen(output,"a");
   else ofp=fopen(output,"w");
   while((fgets(str1,N+2,ifp))!=NULL){
     token1= strtok(str1," ");
     while(token1){
       char *s1=(char *)malloc((N+2)*sizeof(char));
       int l=strlen(token1);int i,j=0;
       for(i=l-1;i>=0;i--){s1[j]=token1[i];j++;}s1[j]='\0';
       fprintf(ofp,"%s\n",s1);
       token1=strtok(NULL," ");
     }
     
   }
   free(token1);
   free(str1); 
   fclose(ifp);
   fclose(ofp);
   return 0;
}
 
