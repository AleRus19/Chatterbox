int somma(int a, int b){
  return a+b;
}

int differenza(int a, int b){
  return a-b;
}
