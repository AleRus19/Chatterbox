#include<stdio.h>
#include "tokenizer.h"

int main(void){
  printf("%d",somma(2,3));
  differenza(3,1);
  return 0;
}
