#define _POSIX_C_SOURCE 200112L
#include<stdio.h>
#include<stdlib.h>
#include<time.h>


#define N 1000
#define K 10

int main(int argc,char *argv[]){
  unsigned int seedp=0;int x=0;
  srand(time(NULL));  
  int *ptr=(int *)calloc(K,sizeof(int)) ; 
  for(int i=0;i<N;i++){
    x=rand_r(&seedp)%K;
    ptr[x]++; 
  }
  for(int i=0;i<K;i++){
    printf("%d: %.2f\n",i,(float)ptr[i]/N*100); 
  }
  free(ptr);
  return 0;
}
