#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<pthread.h>

struct node{
  int info;
  struct node *next;
};

struct argT{
  int nprod;
  int max;
};

int nelem=0;
int terminati=0;
struct node *head=NULL;
struct node *last=NULL;

pthread_mutex_t mtx=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t empty=PTHREAD_COND_INITIALIZER;

void push(int key){
    pthread_mutex_lock(&mtx);
    struct node* n=malloc(sizeof(struct node));
    n->info=key;
    n->next=NULL;
    if(head==NULL){head=n;last=head;}
    else{ 
      last->next=n;
      last=last->next;
    }
    nelem++;
    printf("Inserito:%d\n",n->info);
    if(n->info==-1)pthread_cond_broadcast(&empty);
    else pthread_cond_signal(&empty);
    pthread_mutex_unlock(&mtx);
}



static void *prod(void* e){
  struct argT* m=(struct argT*)e;
  for(int i=0;i<m->max;i++){
    int x=rand()%10;
    push(x); 
  } 
  pthread_mutex_lock(&mtx);
  terminati++;
  pthread_mutex_unlock(&mtx);
  if(terminati==m->nprod){
    printf("Genera:-1\n");
    push(-1);
  }
  return (void*) 2;
}



int pop(){
  pthread_mutex_lock(&mtx);
  while(nelem==0){
    pthread_cond_wait(&empty,&mtx);
    //printf("Consumatore risvegliato\n");
  }
  struct node * n=head; 
  if(n->info==-1){
    //printf("Il produttore ha terminato\n");
    pthread_mutex_unlock(&mtx);
    return -1;
  }
  head=head->next;
  nelem--;printf("Consuma:%d\n",n->info);
  pthread_mutex_unlock(&mtx);
  free(n);
  return 0;
}


static void *cons(void* arg){
  while(1){
    int c=pop();
    if(c==-1){printf("Il produttore ha terminato\n");return (void*)2;}
  }
  return (void*) 3;
}

int main(int argc,char *argv[]){
  int np=atoi(argv[1]);
  int nc=atoi(argv[2]);
  int max=(int)atoi(argv[3])/np;
  pthread_t *ptrp=(pthread_t *)malloc(np*sizeof(pthread_t));
  pthread_t *ptrc=(pthread_t *)malloc(nc*sizeof(pthread_t));
  int *statusp=(int *)malloc(np*sizeof(pthread_t)); 
  int *statusc=(int *)malloc(nc*sizeof(int)); 
  int err; struct argT *e=malloc(sizeof(struct argT));
  e->nprod=np;
  e->max=max;  
  for(int i=0;i<np;i++){
    if(err=pthread_create(&ptrp[i],NULL,prod,(void*)e)!=0){
      perror("Error: ");
      exit(EXIT_FAILURE);
    }
  }
  for(int i=0;i<nc;i++){
    if(err=pthread_create(&ptrc[i],NULL,cons,NULL)!=0){
      perror("Error: ");
      exit(EXIT_FAILURE);
    }
  }
  for(int i=0;i<np;i++){
    pthread_join(ptrp[i],(void*)&statusp[i]);
  }
  for(int i=0;i<nc;i++){
    pthread_join(ptrc[i],(void*)&statusc[i]);
  }
  for(int i=0;i<np;i++){
    printf("StatusP:%d\n",statusp[i]);
  }
  for(int i=0;i<nc;i++){
    printf("StatusC%d:-%d\n",i,statusc[i]);
  }
  return 0;
}

