#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(int argc,char *argv[]){
  int child_pid;int status;
  while(1){
    char  *line=(char *)malloc(100*sizeof(char));
    printf(">: ");
    fgets(line,100,stdin);
    line[strlen(line)-1]='\0';
   char *token1=strtok(line," ");
   char **array=(char **)malloc(100*sizeof(char *));
   int i=0;char path[100]="/bin/";
   while(token1){
     array[i]=token1;
     i++;
      if(strcmp(array[0],"exit\n")==0 || strcmp(array[0],"exit")==0)return 0;  
     token1=strtok(NULL," ");  
  }  
   array[i]=NULL;i++;
   strcat(path,array[0]);
   printf("path: %s\n",path);
   child_pid = fork(); 
   if (child_pid == 0) {
     execv(path,array);
     return 0;
   } 
   else {
     waitpid(child_pid,&status,0);
     fflush(stdout);
     fflush(stdin);   
     free(line);
     free(array);
   }
 }
 return 0;

}
