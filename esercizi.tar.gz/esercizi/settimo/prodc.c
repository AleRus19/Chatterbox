#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<time.h>

pthread_mutex_t mtx=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t empty=PTHREAD_COND_INITIALIZER;
pthread_cond_t full=PTHREAD_COND_INITIALIZER;


static int x;
int nelem=0;


static void* producer(void *arg){
  for(int i=0;i<6;i++){
    pthread_mutex_lock(&mtx);
    while(nelem==1){
      pthread_cond_wait(&full,&mtx);
      printf("Risvegliato Produttore\n"); fflush(stdin);
     
    }
    if(i==5){
      printf("Genera:-1\n");
      x=-1;nelem=1; 
    }
   else{
        x=rand()%10;
        printf("Genera: %d\n",x);
        sleep(2);
        nelem=1;
    }
   pthread_cond_signal(&empty);   
   pthread_mutex_unlock(&mtx);  
  }   
  return (void*) 0;
}



static void* consumer(void *arg){
  while(1){
    pthread_mutex_lock(&mtx);
    while(nelem==0){
      pthread_cond_wait(&empty,&mtx);
      printf("Risvegliato Consumatore\n"); fflush(stdin);
    }
    printf("Consuma: %d\n",x);sleep(2);
    if(x==-1){
      printf("Il produttore ha terminato\n");nelem=0;
      pthread_cond_signal(&full);
      pthread_mutex_unlock(&mtx);
      return (void*) 0;
    }
    nelem=0;
    pthread_cond_signal(&full);
    pthread_mutex_unlock(&mtx);
  }
}


int main(int argc,char *argv[]){
  pthread_t tidp;
  pthread_t tidc;
  int err;int status;
  if(err=pthread_create(&tidp,NULL,producer,NULL)!=0){
    perror("tidp: ");
  } 
  if(err=pthread_create(&tidc,NULL,consumer,NULL)!=0){
    perror("tidp: ");
  } 

  else {
    pthread_join(tidp,(void*)&status);
    pthread_join(tidc,(void*)&status);
    printf("Consumer è terminato: %d\n",status);
    printf("Producer è terminato: %d\n",status);
  }
  return 0;
}
