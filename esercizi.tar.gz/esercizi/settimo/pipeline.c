#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<pthread.h>

struct node{
  char s[255];
  struct node *next;
};
/*Coda Righe*/
struct node *head=NULL;
struct node *last=NULL;

/*Coda Parole*/
struct node *head1=NULL;
struct node *last1=NULL;

int i1=9;
int nelem=0;
int nelemt=0;

/*Variabili di condizione e mutua esclusione per T1-T2*/
pthread_mutex_t mtx=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t empty=PTHREAD_COND_INITIALIZER;
pthread_cond_t full=PTHREAD_COND_INITIALIZER; 

/*Variabili di condizione e mutua esclusione per T2-T3*/
pthread_mutex_t mtxt=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t emptyt=PTHREAD_COND_INITIALIZER;
pthread_cond_t fullt=PTHREAD_COND_INITIALIZER; 

/************************************************************************************************/
//T1 buffer 1 posizione
void inserisci(char *s){
    pthread_mutex_lock(&mtx);
    while(nelem==1){
      pthread_cond_wait(&full,&mtx);
      // printf("T1 risvegliato");  
    }
    struct node* n=malloc(sizeof(struct node));
    strcpy(n->s,s);
    n->next=NULL;
    if(head==NULL){head=n;last=head;nelem++;}
    else{ 
      last->next=n;
      last=last->next;
      nelem++;
    }
    // printf("Inserito:%s\n",n->s);sleep(2);
    pthread_cond_signal(&empty);
    pthread_mutex_unlock(&mtx);
}

static void *fun1(void* file){
  FILE *fp=fopen((char *)file,"r");
  char s[255];
  if(fp==NULL){perror("Error: "); return (void*) -1;}
  while((fgets(s,255,fp))!=NULL){
    inserisci(s);
  }
  fclose(fp);
  inserisci("EOF");
  return (void*) 1;
}
/***************************************************************************************/
void InsertToken(char *s){
  pthread_mutex_lock(&mtxt);
  while(nelemt==10){
      pthread_cond_wait(&fullt,&mtxt);
      // printf("T2 risvegliato");  
    }
    struct node* n=malloc(sizeof(struct node));
    strcpy(n->s,s);
    n->next=NULL;
    if(head1==NULL){head1=n;last1=head1;nelemt++;}
    else{ 
      last1->next=n;
      last1=last1->next;
      nelemt++;
    }
    // printf("Inserito:%s\n",n->s);sleep(2);
    pthread_cond_signal(&emptyt);
    pthread_mutex_unlock(&mtxt);
}


void Tokenizza(char *s){
  char *token=strtok(s," ");
  while(token){
    InsertToken(token);    
    token=strtok(NULL," ");
  }
  return ;
}


int consuma(){
  pthread_mutex_lock(&mtx);
  while(nelem==0){
    pthread_cond_wait(&empty,&mtx);
    //printf("Consumatore risvegliato\n");
  }
  struct node * n=head;
  head=head->next;
  if(strcmp(n->s,"EOF")==0){
    //printf("Il produttore ha terminato\n");
    pthread_mutex_unlock(&mtx);//free(n);nelem--;
    return -1;
  }
  nelem--;sleep(2);
  pthread_cond_signal(&full);
  pthread_mutex_unlock(&mtx);
  Tokenizza(n->s);free(n);
  return 0;
}

static void *fun2(void* arg){
  while(1){
    int c=consuma();
    if(c==-1){InsertToken("EOF");return (void*)2;}
  }
  return (void*) 2;
}


/*************************************************************************************************************/

int check(struct node *l,char *key){
  if(l==NULL)return 1;
  while(l!=NULL){
    // printf("%s=%s\n",l->s,key);sleep(1);
    if(strcmp(l->s,key)==0) return 0;
    l=l->next;
  }
  return 1;
}
int consumaToken(struct node* *ptr){
  pthread_mutex_lock(&mtxt);
  while(nelemt==0){
    pthread_cond_wait(&emptyt,&mtxt);
    // printf("Consumatore risvegliato\n");
  }
  struct node * n=head1;
  head1=head1->next;
  if(strcmp(n->s,"EOF")==0){
    // printf("Il produttore ha terminato\n");
    pthread_mutex_unlock(&mtxt);free(n);nelemt--;
    return -1;
  }
  nelemt--;
  pthread_cond_signal(&fullt);
  pthread_mutex_unlock(&mtxt);
  int bl=check(*ptr,n->s);
  if(bl>0){
    struct node *p=malloc(sizeof(struct node));
    p->next=NULL;
    strcpy(p->s,n->s);
    if(*ptr==NULL){*ptr=p;return 0;}
    struct node *temp=*ptr;
    while(temp->next!=NULL){temp=temp->next;}
    temp->next=p;
  }
  free(n);
  return 0;
}

void stampa(struct node *l){
  while(l!=NULL){printf("%s\n",l->s);l=l->next;}
}

static void *fun3(void* arg){
  struct node *l=NULL;
  while(1){
    int c=consumaToken(&l);
    if(c==-1){stampa(l);return (void*)3;}
  }
}


/*******************************************************************************************************/

int main(int argc,char *argv[]){
  char *file=argv[1];
  pthread_t t1,t2,t3;
  int status1,status2,status3;
  int err;
  if(err=pthread_create(&t1,NULL,fun1,file)!=0){
    perror("Error: ");
    exit(EXIT_FAILURE);
  }
  if(err=pthread_create(&t2,NULL,fun2,NULL)!=0){
    perror("Error: ");
    exit(EXIT_FAILURE);
  }
  if(err=pthread_create(&t3,NULL,fun3,NULL)!=0){
    perror("Error: ");
    exit(EXIT_FAILURE);
  }  
  pthread_join(t1,(void*)&status1);
  pthread_join(t2,(void*)&status2);
  pthread_join(t3,(void*)&status3);
  printf("1:%d\n2:%d\n3:%d\n",status1,status2,status3);
  return 0;
}
