#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<time.h>

int *stato;
int N;

pthread_mutex_t mtx=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t *full=PTHREAD_COND_INITIALIZER;

void tempo(){
   struct timespec slptm;
    slptm.tv_sec = 0;
    slptm.tv_nsec = rand()%1000;      //1000 ns = 1 us
    nanosleep(&slptm,NULL);
 
}

static void *filosofo(void* a){
  int pos=*((int *)a);
  //printf("pos:%d\n",pos);sleep(2);
  for(int i=0;i<3;i++){
    pthread_mutex_lock(&mtx);
    printf("Filosofo %d acquisisce lock\n",pos%N);
    printf("Filosofo %d: vuole mangiare\n",pos%N);
    stato[pos]=1;sleep(2);
    while((stato[(pos-1)%N]==2) || (stato[(pos+1)%N]==2)){
      printf("Filosofo %d: tutto full\n",pos%N);sleep(2);
      pthread_cond_wait(&full[pos],&mtx);
    }
    printf("Filosofo %d: mangia\n",pos%N);
    stato[pos]=2;
    printf("Filosofo %d ha finito di mangiare\n",pos%N);
    printf("Filosofo %d: rilascia il lock\n",pos%N);
    pthread_mutex_unlock(&mtx);
    pthread_mutex_lock(&mtx);
    tempo();
    printf("Filosofo %d acquisisce lock\n",pos%N);
    printf("Filosofo %d: ritorna a pensare\n",pos%N);
    stato[pos]=0;
    if((stato[(pos-1)%N]==1) && (stato[(pos-2)%N]!=2)){
      stato[(pos-1)%N]=2;
      printf("Il filosofo %d viene riattivato\n",(pos-1)%N);
      pthread_cond_signal(&full[(pos-1)%N]);
    }
    if((stato[(pos+1)%N]==1) && (stato[(pos+2)%N]!=2)){
      stato[(pos+1)%N]=2;
      printf("IL filosofo %d viene riattivato\n",(pos+1)%N);
      pthread_cond_signal(&full[(pos+1)%N]);
    }
     printf("Filosofo %d rilascia il lock dopo aver risvegliato vicini\n",pos%N);
     pthread_mutex_unlock(&mtx);tempo();
  }
  return (void*) 3;
}

void Alloca(int n){
  stato=(int *)calloc(n,sizeof(int));
  full=(pthread_cond_t *)malloc(n*sizeof(pthread_cond_t));
}

int main(int argc, char *argv[]){
  int n=atoi(argv[1]);
  Alloca(n); N=n;
  pthread_t *ptr=(pthread_t *)malloc(n*sizeof(pthread_t));
  int *status=(int *)malloc(n*sizeof(int));
  int *posizione=(int *)malloc(n*sizeof(int));
  int err;
  for(int i=0;i<n;i++){
    int *arg = malloc(sizeof(arg));
    if(arg==NULL){
      fprintf(stderr, "Couldn't allocate memory for thread arg.\n");
      exit(EXIT_FAILURE);
     }
    *arg = i;  
    if(err=pthread_create(&ptr[i],NULL,filosofo,arg)!=0){
      perror("Error: ");
      exit(EXIT_FAILURE);
    }
  }
  for(int i=0;i<n;i++){
    pthread_join(ptr[i],(void*)&status[i]);
  }
   
 for(int i=0;i<n;i++){
    printf("StatusFilosofo:%d\n",status[i]);
  }
 
  return 0;
}
