#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<sys/wait.h>


int cmp(char *s1, char *s2){
  int i=0;
  if(strlen(s1)==strlen(s2)) return 0;
  return -1;    
}

int main(int argc,char *argv[]){
  char *prog,**args;
  int child_pid;int status;
   
 
  size_t bufsize=0;
  int bl=0;
  char  *line;char **array;
  while(1){
   line=(char *)malloc(256*sizeof(char));
   printf(">: ");fflush(stdin);
   scanf("%[^\n]s",line);
   char *token1=strtok(line," ");
   array=(char **)malloc(256*sizeof(char *));
   int i=0;
   while(token1){
     array[i]=token1;
     i++;
     token1=strtok(NULL," ");  
  }
   if(strcmp(array[0],"exit\n")==0 || strcmp(array[0],"exit")==0)return 0;
   array[i]=NULL;i++;
   if(strcmp(array[0],"ls\n")==0 ||strcmp(array[0],"ls")==0){
      child_pid = fork(); 
      if (child_pid == 0) {
        execv("/bin/ls",array);
      } 
     else {
       waitpid(child_pid,&status,0);
      
     }
   }

   if(strcmp(array[0],"cat\n")==0 ||strcmp(array[0],"cat")==0){
      child_pid = fork(); 
      if (child_pid == 0) {
        execv("/bin/cat",array);
     } 
     else {
       waitpid(child_pid,&status,0);
       
  
      }
   }
  
   printf("ok");

   line=NULL;
    array=NULL;
  }
  return 0;

}
